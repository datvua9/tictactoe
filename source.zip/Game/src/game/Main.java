package game;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.Timer;
import java.util.TimerTask;

public class Main {
	
    private static int secX = 0;
    private static int secO = 0;
    private static Timer timerX = new Timer();
    private static Timer timerO = new Timer();
    private static JLabel lblTimeX;
    private static JLabel lblTimeO;
    private static JButton btnStart;
    private static Board board;
    private static Cell cell;
   // private static SqlManager sqlManager = new SqlManager();

    public static void main(String[] args) {
        board = new Board();
//        board.setEndGameListener(new EndGameListener() {
//            @Override
//            public void end(String player, int st) {
//                if(st == Board.ST_WIN) {
//                	try {
//                		sqlManager.addData("Người chơi " + player +"thắng" );
//                	} catch(Exception e) {
//                		e.printStackTrace();
//                	}
//                	
//                	JOptionPane.showMessageDialog(null, "Người chơi " + player + "Thắng");
//                	stopGame();
//                }else if(st == Board.ST_DRAW) {
//                	JOptionPane.showMessageDialog(null, "Hòa rồi");
//                }            	           
//                try {
//                	sqlManager.addData("Hòa ");
//                }catch (ClassNotFoundException e) {
//                	 e.printStackTrace();
//                }catch(SQLException e) {
//                	e.printStackTrace();
//                }
//               stopGame();
//            }
//        });
        board.setEndGameListener(new EndGameListener() {
            @Override
            public void end(String player, int st) {
                if(st == Board.ST_WIN){
                    JOptionPane.showMessageDialog(null, "Người chơi " + player + " thắng");
                    stopGame();
                }else if(st == Board.ST_DRAW){
                    JOptionPane.showMessageDialog(null, "Hòa rồi");
                    stopGame();
                }
            }
        });

        JPanel jPanel = new JPanel();
        BoxLayout boxLayout = new BoxLayout(jPanel,BoxLayout.Y_AXIS);
        jPanel.setLayout(boxLayout);

        board.setPreferredSize(new Dimension(600, 580));

        FlowLayout flowLayout = new FlowLayout(FlowLayout.CENTER, 0, 0);

        JPanel bottomPanel = new JPanel();
        bottomPanel.setLayout(flowLayout);
lblTimeX = new JLabel("pX: 0:0");
        btnStart = new JButton("Start");
        
        lblTimeO = new JLabel("    pO: 0:0");
        bottomPanel.add(btnStart);
        bottomPanel.add(lblTimeX);
        
        bottomPanel.add(lblTimeO);
        btnStart.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(btnStart.getText().equals("Start")){
                    startGame();
                }else{
                    stopGame();
                }
            }
        });

        jPanel.add(board);
        jPanel.add(bottomPanel);

        Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();

        JFrame jFrame = new JFrame("Co ca ro");
        jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jFrame.setResizable(false);
        jFrame.add(jPanel);
        int x =  ((int)dimension.getWidth() / 2 - (jFrame.getWidth() / 2));
        int y = ((int) dimension.getHeight() / 2 - (jFrame.getHeight() / 2));
        jFrame.setLocation(x, y);
        jFrame.pack();
        jFrame.setVisible(true);
    }

    private static void startGame(){
        int choice = JOptionPane.showConfirmDialog(null, "Người chơi O đi trước đúng không?", "Ai là người đi trước?", JOptionPane.YES_NO_OPTION);
        board.reset();
        String currentPlayer = (choice == 0) ? Cell.O_VALUE : Cell.X_VALUE;
        board.setCurrentPlayer(currentPlayer);
        secO = 0; 
        secX = 0; 
        lblTimeO.setText("pO: 0:0");
        lblTimeX.setText("   pX: 0:0");
        timerO.cancel();
        timerX.cancel();
        timerO = new Timer();
        timerX = new Timer();

        timerO.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                if(board.getCurrentPlayer().equals(Cell.O_VALUE)) {
                    secO++;
                    String value ="   pO "+ secO / 60 + " : " + secO % 60;
                    lblTimeO.setText(value);
                }
            }
        }, 1000, 1000);

        timerX.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                if(board.getCurrentPlayer().equals(Cell.X_VALUE)) {
                    secX++;
                    String value =" pX "+ secX / 60 + " : " + secX % 60;
                    lblTimeX.setText(value);
                }
            }
        }, 1000, 1000);

        btnStart.setText("Stop");
    }

    
    private static void stopGame(){
        btnStart.setText("Start");
        secO = 0;
        secX = 0;
        lblTimeO.setText("0:0");
        timerO.cancel();
        timerX.cancel();
        timerO = new Timer();
        timerX = new Timer();
        board.reset();
    }
}