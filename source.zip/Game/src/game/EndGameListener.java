package game;

public interface EndGameListener {
    public void end(String player, int st);
}